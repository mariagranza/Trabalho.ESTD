package estruturas;

// Classe Iterador
public class ExercicioIterador {
    private ListaDEncadeada lista;
    private No atual;

    public ExercicioIterador(ListaDEncadeada lista, No inicio) {
        this.lista = lista;
        this.atual = inicio;
    }

    public No getAtual() {
        return this.atual;
    }

    // Avança para o próximo nó
    public void avancar() {
        if (this.atual != null) {
            this.atual = this.atual.proximo;
        }
    }

    // Retrocede para o nó anterior
    public void retroceder() {
        if (this.atual != null) {
            this.atual = this.atual.anterior;
        }
    }
    
    // Insere um novo nó após o nó atual
    public void inserirAposAtual(int valor) {
        if (this.atual != null) {
            No novoNo = new No(valor);
            novoNo.proximo = this.atual.proximo;
            novoNo.anterior = this.atual;
            if (this.atual.proximo != null) {
                this.atual.proximo.anterior = novoNo;
            }
            this.atual.proximo = novoNo;
        }
    }
    
    // Remove o nó após o nó atual
    public void removerAposAtual() {
        if (this.atual != null && this.atual.proximo != null) {
            No removido = this.atual.proximo;
            this.atual.proximo = removido.proximo;
            if (removido.proximo != null) {
                removido.proximo.anterior = this.atual;
            }
        }
    }
    
    // Insere um novo nó antes do nó atual
    public void inserirAntesAtual(int valor) {
        if (this.atual != null) {
            No novoNo = new No(valor);
            novoNo.anterior = this.atual.anterior;
            novoNo.proximo = this.atual;
            if (this.atual.anterior != null) {
                this.atual.anterior.proximo = novoNo;
            } else {
                lista.inicio = novoNo;
            }
            this.atual.anterior = novoNo;
        }
    }
    
    // Remove o nó antes do nó atual
    public void removerAntesAtual() {
        if (this.atual != null && this.atual.anterior != null) {
            No removido = this.atual.anterior;
            this.atual.anterior = removido.anterior;
            if (removido.anterior != null) {
                removido.anterior.proximo = this.atual;
            } else {
                lista.inicio = this.atual;
            }
        }
    }
}




