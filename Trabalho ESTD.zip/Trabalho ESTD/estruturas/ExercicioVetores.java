package estruturas; 
import java.util.Arrays;


public class ExercicioVetores {

 
    public Integer[] elementos;
    private int tamanho;
    private int capacidade;

    // Construtor que inicializa o vetor com uma capacidade específica
    public ExercicioVetores(int capacidade) {
        this.elementos = new Integer[capacidade]; // Cria um array com a capacidade especificada
        this.capacidade = capacidade; // Define a capacidade do vetor
        this.tamanho = 0; // Inicializa o tamanho como zero (nenhum elemento inserido)
    }


    public void adicionar(Integer valor) {
        // Se o vetor estiver cheio, aumenta a capacidade antes de adicionar o novo elemento
        if (this.capacidade == this.tamanho) {
            this.aumentarCapacidade();
        }

        // Insere o novo elemento na próxima posição disponível e incrementa o tamanho
        this.elementos[this.tamanho] = valor;
        this.tamanho++;
    }

    // Método privado para aumentar a capacidade do vetor quando necessário
    private void aumentarCapacidade() {
        // Define a nova capacidade como 1.5 vezes a capacidade atual
        int novaCapacidade = this.capacidade + (this.capacidade / 2);
        Integer[] novosElementos = new Integer[novaCapacidade]; // Cria um novo array maior

        // Copia os elementos do array antigo para o novo array
        for (int i = 0; i < this.tamanho; i++) {
            novosElementos[i] = this.elementos[i];
        }

        // Atualiza o array de elementos e sua capacidade
        this.elementos = novosElementos;
        this.capacidade = novaCapacidade;
    }

    // Método para exibir todos os elementos armazenados no vetor
    public void mostrarElementos() {
        System.out.println("-----");
        System.out.println("Elementos no vetor");
        // Percorre e imprime todos os elementos válidos do vetor
        for (int i = 0; i < tamanho; i++) {
            System.out.println(this.elementos[i]);
        }
        System.out.println("-----");
    }

    public void buscar(Integer valor) {
        Arrays.sort(this.elementos, 0, this.tamanho); // Ordena apenas os elementos válidos do vetor
        int esquerda = 0;
        int direita = this.tamanho - 1;
    
        while (esquerda <= direita) {
            int meio = esquerda + (direita - esquerda) / 2;
    
            if (this.elementos[meio].equals(valor)) {
                System.out.println("Valor encontrado na posição " + meio);
                return; // Encerra a busca
            }
    
            if (this.elementos[meio] < valor) {
                esquerda = meio + 1; // Busca na metade direita
            } else {
                direita = meio - 1; // Busca na metade esquerda
            }
        }
    
        System.out.println("Valor não encontrado");
    }
    

      // método para adicionar um valor no início do vetor
      public void adicionarNoInicio(Integer valor) {
        if (this.capacidade == this.tamanho) {
            this.aumentarCapacidade();
        }

        // Desloca todos os elementos uma posição para a direita
        for (int i = this.tamanho; i > 0; i--) {
            this.elementos[i] = this.elementos[i - 1];
        }

        // Insere o novo valor na primeira posição
        this.elementos[0] = valor;
        this.tamanho++;
    }
}

