package estruturas;

public class ListaDEncadeada {

    public No inicio;

    public ListaDEncadeada() {
        this.inicio = null;
    }

    // Adiciona um novo nó no início da lista
    public void adicionarAoInicio(int valor) {
        No no = new No(valor);
        if (this.inicio != null) {
            no.proximo = this.inicio;
            this.inicio.anterior = no;
        }
        this.inicio = no;
    }

    // Adiciona um novo nó no final da lista
    public void adicionarAoFinal(int valor) {
        No no = new No(valor);
        if (this.inicio == null) {
            this.inicio = no;
            return;
        }
        No atual = this.inicio;
        while (atual.proximo != null) {
            atual = atual.proximo;
        }
        atual.proximo = no;
        no.anterior = atual;
    }
    
    // Insere um novo nó após um nó com o valor informado
    public void inserirAposValor(int valorReferencia, int novoValor) {
        No atual = this.inicio;
        while (atual != null && atual.dado != valorReferencia) {
            atual = atual.proximo;
        }
        if (atual != null) {
            No novoNo = new No(novoValor);
            novoNo.proximo = atual.proximo;
            novoNo.anterior = atual;
            if (atual.proximo != null) {
                atual.proximo.anterior = novoNo;
            }
            atual.proximo = novoNo;
        }
    }
    
    // Conta o número de nós na lista
    public int contarNos() {
        int contador = 0;
        No atual = this.inicio;
        while (atual != null) {
            contador++;
            atual = atual.proximo;
        }
        return contador;
    }

    // Exibe todos os nós da lista
    public void mostrarNos() {
        No atual = this.inicio;
        while (atual != null) {
            System.out.print(atual.dado + " <-> ");
            atual = atual.proximo;
        }
        System.out.println("null");
    }
    
    public ExercicioIterador getIterador() {
        return new ExercicioIterador(this, this.inicio);
    }
}

